# Ícones

Todos os ícones utilizados na Santander Dev Week 2023 em formato SVG.
